package client_server;


import java.io.*;
import java.net.*;

public class Client {

    public static void main(String[] args) throws Exception {
        String ip = "127.0.0.1";
        int port = 25550;

        Socket socket = new Socket(ip, port);
        System.out.println("Client connecté au serveur !");

        BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in));
        BufferedReader serverRead = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintWriter serverWrite = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);

        String msg = "";
        while (!msg.equals("END")) {
            System.out.println("Donne totalCount (ou END pour quitter) : ");
            msg = keyboard.readLine();

            serverWrite.println(msg);
            if (!msg.equals("END")) {
                String response = serverRead.readLine();
                System.out.println("Réponse du serveur : points dans disque = " + response);

                double pi = 4.0 * Integer.parseInt(response) / Integer.parseInt(msg);
                System.out.println("PI estimé = " + pi);
            }
        }

        socket.close();
        System.out.println("Client terminé.");
    }
}
