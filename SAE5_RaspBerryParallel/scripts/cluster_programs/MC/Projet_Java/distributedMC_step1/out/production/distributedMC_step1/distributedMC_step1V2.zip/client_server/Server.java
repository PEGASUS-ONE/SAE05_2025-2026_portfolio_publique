package client_server;

import java.io.*;
import java.net.*;

public class Server {

    public static void main(String[] args) throws Exception {
        int port = 25550;
        ServerSocket server = new ServerSocket(port);
        System.out.println("Serveur démarré sur le port " + port);

        while (true) {
            Socket clientSocket = server.accept();
            System.out.println("Nouveau client connecté : " + clientSocket);
            new Thread(new Worker(clientSocket)).start();
        }
    }
}

// Thread qui gère un client
class Worker implements Runnable {
    private Socket socket;

    Worker(Socket s) {
        this.socket = s;
    }

    @Override
    public void run() {
        try {
            BufferedReader bRead = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter pWrite = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);

            String str;
            while ((str = bRead.readLine()) != null) {
                if (str.equals("END")) break;

                int totalCount = Integer.parseInt(str);
                int inside = computeMonteCarlo(totalCount);

                System.out.println("Client : " + socket + " → totalCount = " + totalCount + " → inside = " + inside);
                pWrite.println(inside);
            }

            bRead.close();
            pWrite.close();
            socket.close();
            System.out.println("Client déconnecté : " + socket);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private int computeMonteCarlo(int totalCount) {
        int inside = 0;

        for (int i = 0; i < totalCount; i++) {
            double x = Math.random();
            double y = Math.random();
            if (x * x + y * y <= 1.0) inside++;
        }

        return inside;
    }
}
